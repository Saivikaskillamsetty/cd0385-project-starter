"""Generate the in-house 'Gateway prompts' evaluation set.

Synthetic but realistic prompts that bank employees / customers send to an LLM through a
GenAI gateway (summarise this email, draft a reply, debug this log, fill this KYC form...).
PII values are generated with Faker (en_US / en_IN / en_GB), so gold spans are exact and the
set is held out from every candidate model's training data. ~23% of prompts contain no PII
but do contain look-alike distractors (amounts, tickers, company names, reference numbers,
generic dates) to measure false alarms.

No LLM was used to generate this data.
"""
import json
import random
import re
import string
import sys

from faker import Faker

SEED = 20261031
random.seed(SEED)
FAKERS = {"en_US": Faker("en_US"), "en_IN": Faker("en_IN"), "en_GB": Faker("en_GB")}
for i, f in enumerate(FAKERS.values()):
    f.seed_instance(SEED + i)
LOCALE_W = [("en_US", 0.55), ("en_IN", 0.30), ("en_GB", 0.15)]


def pick_locale():
    r, acc = random.random(), 0
    for loc, w in LOCALE_W:
        acc += w
        if r <= acc:
            return loc
    return "en_US"


def _pan():
    return "".join(random.choices(string.ascii_uppercase, k=3)) + "P" + random.choice(string.ascii_uppercase) + \
        "".join(random.choices(string.digits, k=4)) + random.choice(string.ascii_uppercase)


def _apikey():
    return random.choice(["sk-", "AKIA", "ghp_", "xoxb-"]) + "".join(random.choices(string.ascii_letters + string.digits, k=28))


def _fmt_date(d, loc):
    fmts = ["%d/%m/%Y", "%d %B %Y", "%Y-%m-%d"] if loc != "en_US" else ["%m/%d/%Y", "%B %d, %Y", "%Y-%m-%d"]
    return d.strftime(random.choice(fmts))


# slot -> (gold label or None for distractor/ignore, generator(fake, loc))
def SLOTS():
    return {
        "NAME": ("PERSON", lambda f, l: f.name()),
        "NAME2": ("PERSON", lambda f, l: f.name()),
        "FIRST": ("PERSON", lambda f, l: f.first_name()),
        "EMAIL": ("EMAIL", lambda f, l: f.email()),
        "PHONE": ("PHONE", lambda f, l: f.phone_number()),
        "ADDRESS": ("ADDRESS", lambda f, l: re.sub(r"\s*\n\s*", ", ", f.address())),
        "DOB": ("DATE", lambda f, l: _fmt_date(f.date_of_birth(minimum_age=18, maximum_age=85), l)),
        "TXDATE": ("DATE", lambda f, l: _fmt_date(f.date_between(start_date="-120d", end_date="today"), l)),
        "CARD": ("FIN_ID", lambda f, l: f.credit_card_number()),
        "ACCT": ("FIN_ID", lambda f, l: f.bban() if l == "en_GB" else "".join(random.choices(string.digits, k=random.choice([10, 11, 12, 14])))),
        "IBAN": ("FIN_ID", lambda f, l: f.iban()),
        "ROUTING": ("FIN_ID", lambda f, l: f.aba() if l == "en_US" else f.swift()),
        "SSN": ("GOV_ID", lambda f, l: FAKERS["en_US"].ssn() if l != "en_IN" else _pan()),
        "AADHAAR": ("GOV_ID", lambda f, l: FAKERS["en_IN"].aadhaar_id()),
        "PAN": ("GOV_ID", lambda f, l: _pan()),
        "PASSPORT": ("GOV_ID", lambda f, l: f.passport_number()),
        "IP": ("ONLINE_ID", lambda f, l: f.ipv4()),
        "USERNAME": ("ONLINE_ID", lambda f, l: f.user_name()),
        "PROFILE": ("ONLINE_ID", lambda f, l: f"https://www.linkedin.com/in/{f.user_name()}"),
        "PASSWORD": ("SECRET", lambda f, l: f.password(length=random.choice([10, 12, 14]))),
        "APIKEY": ("SECRET", lambda f, l: _apikey()),
        # distractors: not PII. REF is an ignore region (arguably sensitive, so neither rewarded nor penalised)
        "REF": (None, lambda f, l: random.choice(["CASE-", "INC", "TKT-", "REQ"]) + "".join(random.choices(string.digits, k=7))),
        "AMOUNT": ("_NONPII", lambda f, l: random.choice(["$", "USD ", "INR ", "£", "Rs. "]) + f"{random.randint(50, 950000):,}" + random.choice(["", ".00", ".50"])),
        "COMPANY": ("_NONPII", lambda f, l: f.company()),
        "TICKER": ("_NONPII", lambda f, l: random.choice(["JPM", "MSFT", "NVDA", "AAPL", "INFY", "TCS", "HDFCBANK", "BAC"])),
        "PCT": ("_NONPII", lambda f, l: f"{random.uniform(0.1, 12):.2f}%"),
        "QUARTER": ("_NONPII", lambda f, l: random.choice(["Q1", "Q2", "Q3", "Q4"]) + " " + str(random.choice([2025, 2026, 2027]))),
        "CITYPUB": ("_NONPII", lambda f, l: random.choice(["New York", "London", "Hyderabad", "Mumbai", "Singapore", "Columbus", "Bengaluru"])),
    }


POS_TEMPLATES = [
    "Summarize this customer email in two bullet points: 'Hi, this is {NAME}. My card ending {CARD} was charged {AMOUNT} twice on {TXDATE}. Please call me on {PHONE} or email {EMAIL}.'",
    "Draft a polite reply to {NAME} ({EMAIL}) explaining that the wire to IBAN {IBAN} will settle within 2 business days.",
    "Extract the fields from this KYC form as JSON: Name: {NAME}; DOB: {DOB}; Address: {ADDRESS}; Passport No: {PASSPORT}; Phone: {PHONE}",
    "Customer {NAME} wants to update her mailing address to {ADDRESS}. Her account number is {ACCT}. Write the change request note.",
    "Why is this API call failing? curl -H 'Authorization: Bearer {APIKEY}' https://api.internal.example.com/v2/positions?user={USERNAME}",
    "Rewrite this note more professionally: called {FIRST} back at {PHONE}, he confirmed routing {ROUTING} and account {ACCT} for the ACH setup.",
    "Translate to Hindi: Dear {NAME}, your loan application dated {TXDATE} for {AMOUNT} has been approved. Reference {REF}.",
    "Check this log for anomalies: 2026-10-12T09:14:03Z login failed user={USERNAME} src_ip={IP} attempts=7; 2026-10-12T09:14:09Z login ok user={USERNAME} src_ip={IP}",
    "Please verify the customer's identity: PAN {PAN}, Aadhaar {AADHAAR}, registered mobile {PHONE}, name {NAME}.",
    "My SSN is {SSN} and DOB {DOB}. Can you tell me what documents I need to open a brokerage account?",
    "Write a dispute letter for {NAME}, {ADDRESS}, regarding an unauthorised transaction of {AMOUNT} on card {CARD} dated {TXDATE}.",
    "Here is my config, why doesn't the DB connect? host=db01.prod user={USERNAME} password={PASSWORD} port=5432",
    "Create a meeting summary: attendees {NAME}, {NAME2} and our relationship manager. {NAME2} will send the signed mandate to {EMAIL} by Friday.",
    "Classify the sentiment of this complaint from {NAME} (ph: {PHONE}): 'Third time this month my {COMPANY} payment bounced, fix it or I close the account.'",
    "Fill in the onboarding template for the new hire: Full name {NAME}, personal email {EMAIL}, home address {ADDRESS}, date of birth {DOB}.",
    "Is this a phishing email? 'Dear {FIRST}, your account {ACCT} is locked. Confirm your password at http://secure-verify.example.net and reply with your card {CARD}.'",
    "Convert to a table: {NAME} | {EMAIL} | {PHONE}\n{NAME2} | {PHONE} | {TXDATE}",
    "Draft an SWIFT MT103 narrative for a payment from {NAME} to beneficiary account {IBAN}, BIC {ROUTING}, amount {AMOUNT}.",
    "The client {NAME} (LinkedIn: {PROFILE}) asked about {TICKER} exposure. Write a two-line follow-up for {EMAIL}.",
    "Debug: KeyError when parsing record {{'name': '{NAME}', 'ssn': '{SSN}', 'acct': '{ACCT}'}}",
    "Summarise the call: {NAME} from {CITYPUB} called on {TXDATE} about a stuck refund of {AMOUNT}; callback number {PHONE}.",
    "Mask nothing, just proofread: 'Pls transfer to my acct {ACCT}, IFSC as before. Regards, {FIRST}'",
    "Generate a reminder SMS for {FIRST} at {PHONE} that the EMI of {AMOUNT} is due on {TXDATE}.",
    "Write a short bio for the internal directory: {NAME}, joined {COMPANY} in 2019, reachable at {EMAIL} or {PHONE}.",
    "What does this error mean? AuthError: invalid key {APIKEY} for account {USERNAME}@{COMPANY}",
    "Help me fill this form. Passport: {PASSPORT}; Nationality: Indian; Date of birth: {DOB}; Permanent address: {ADDRESS}",
    "Escalate ticket {REF}: customer {NAME}, card {CARD}, disputed {AMOUNT} on {TXDATE}, contact {EMAIL}.",
    "Explain what this means for {NAME}: 'Your IBAN {IBAN} has been flagged for additional due diligence.'",
    "Rewrite as a formal letter to {NAME}, {ADDRESS}: we have closed account {ACCT} as requested on {TXDATE}.",
    "My wife {NAME2} and I ({NAME}) want a joint account. Our phones are {PHONE} and {PHONE}. What's the process?",
    "Parse this CSV row and validate it: \"{NAME}\",\"{DOB}\",\"{SSN}\",\"{EMAIL}\"",
    "Find the bug: user_password = \"{PASSWORD}\" is hardcoded in settings.py next to ADMIN_EMAIL = \"{EMAIL}\"",
    "Summarise the fraud alert: login from IP {IP} for user {USERNAME} followed by a transfer of {AMOUNT} to account {ACCT}.",
    "Can you make this message friendlier? 'Hi {FIRST}, send the cheque to {ADDRESS} and call {PHONE} once done.'",
    "Write a Python dict for this customer: name {NAME}, aadhaar {AADHAAR}, pan {PAN}, mobile {PHONE}",
]

NEG_TEMPLATES = [
    "Summarize {COMPANY}'s {QUARTER} earnings call in three bullets and compare net interest margin to {PCT}.",
    "Explain the difference between a Roth IRA and a traditional IRA for a new investor.",
    "Write a Python function that validates an IBAN checksum. Do not use external libraries.",
    "What is the current outlook for {TICKER} after the {QUARTER} guidance cut of {PCT}?",
    "Draft a team announcement: the {CITYPUB} office will host the {QUARTER} town hall; lunch budget is {AMOUNT}.",
    "Convert {AMOUNT} to EUR at a rate of 0.92 and show the working.",
    "Translate to French: 'Our branch in {CITYPUB} will be closed for the public holiday.'",
    "Give me a SQL query that returns the top 10 accounts by balance from table accounts(account_id, balance, opened_on).",
    "Ticket {REF} is still open. Write a status update saying the fix will ship in the next release.",
    "Explain KYC and AML requirements for onboarding a small business customer in India.",
    "Write unit tests for a function mask_card(card: str) -> str that keeps only the last 4 digits.",
    "Compare {COMPANY} and {TICKER} on revenue growth; assume growth rates of {PCT} and 4.1%.",
    "What does error code 0x80070005 mean on Windows and how do I fix it?",
    "Summarize the Basel III endgame proposal in plain English for a non-specialist audience.",
    "Write a regex that matches US phone numbers in the format (555) 555-5555.",
    "Our {QUARTER} target is {AMOUNT} in new deposits from the {CITYPUB} region. Draft a motivating note to the sales team.",
    "Explain what a SWIFT BIC code is and how many characters it has.",
    "Rephrase: 'The meeting with {COMPANY} is moved to Thursday at 3pm.'",
    "What is the formula for compound interest? Show an example with principal {AMOUNT} at {PCT} for 5 years.",
    "List five best practices for storing API keys securely in a microservices architecture.",
]


def render(template, loc):
    f = FAKERS[loc]
    slots = SLOTS()
    text, spans = "", []
    pos = 0
    for m in re.finditer(r"\{([A-Z0-9]+)\}", template):
        lit = template[pos:m.start()].replace("{{", "{").replace("}}", "}")
        text += lit
        key = m.group(1)
        label, gen = slots[key]
        val = gen(f, loc)
        start = len(text)
        text += val
        if label != "_NONPII":
            spans.append({"start": start, "end": len(text), "label": label, "slot": key})
        pos = m.end()
    text += template[pos:].replace("{{", "{").replace("}}", "}")
    return text, spans


def main(out_path, n_pos=500, n_neg=150):
    rows = []
    for i in range(n_pos):
        loc = pick_locale()
        t = POS_TEMPLATES[i % len(POS_TEMPLATES)]
        text, spans = render(t, loc)
        rows.append({"id": f"gw-pos-{i}", "text": text, "spans": spans, "locale": loc, "has_pii": True})
    for i in range(n_neg):
        loc = pick_locale()
        t = NEG_TEMPLATES[i % len(NEG_TEMPLATES)]
        text, spans = render(t, loc)
        rows.append({"id": f"gw-neg-{i}", "text": text, "spans": spans, "locale": loc, "has_pii": False})
    random.shuffle(rows)
    with open(out_path, "w") as fh:
        for r in rows:
            fh.write(json.dumps(r) + "\n")
    print(f"wrote {len(rows)} rows to {out_path}")


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "data/gateway_prompts.jsonl")
